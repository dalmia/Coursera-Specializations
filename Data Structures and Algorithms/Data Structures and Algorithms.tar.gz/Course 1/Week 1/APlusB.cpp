#include <iostream>
using namespace std;

int main(){
  int a = 0;
  int b = 0;
  int sum = 0;
  cin >> a;
  cin >> b;
  sum = a + b;
  cout << sum;
  return 0;
}
